﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication10.Models;

namespace WebApplication10.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            IList<Account> account = new List<Account>();
            account.Add(new Account() { ID = 123, AccHolderName = "Sasmita", AccHolderAddress = "Bgr" });
            account.Add(new Account() { ID = 12, AccHolderName = "Mita", AccHolderAddress = "Bgh" });
            account.Add(new Account() { ID = 1, AccHolderName = "Srikanta", AccHolderAddress = "Sbp" });

            ViewData["account"] = account;

            return View();
        }
    }
}
