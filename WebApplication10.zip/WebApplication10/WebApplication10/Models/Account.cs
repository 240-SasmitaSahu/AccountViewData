﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication10.Models
{
    public class Account
    {
        public int ID { get; set; }
        public string AccHolderName { get; set; }
        public string AccHolderAddress { get; set; }
    }
}
